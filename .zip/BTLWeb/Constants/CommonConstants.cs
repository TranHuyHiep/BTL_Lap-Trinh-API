﻿namespace BTLWeb.Constants
{
    public class CommonConstants
    {
        public const string SessionCart = "SessionCart";
    }
}
